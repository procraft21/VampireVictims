package com.example.projectcyber;

public abstract class Entity {

}
