package com.example.projectcyber;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceView;

import androidx.annotation.NonNull;

public class GameView extends SurfaceView implements Runnable{

    /* JOYSTICK VARIABLES ---------------------------------------------------*/
    private boolean isJoyStickOn = false;
    private Point joystickBaseCenter, joystickHandleCenter;
    private static final int JOYSTICK_BASE_RADIUS = 100;
    private static final int JOYSTICK_HANDLE_RADIUS = 50;
    private static Paint JOYSTICK_BASE_PAINT, JOYSTICK_HANDLE_PAINT;
    private static final int JOYSTICK_BASE_COLOR = 0x60FFFFFF,JOYSTICK_HANDLE_COLOR = 0xF0FFFFFF;


    //public GameView(Context context) {
    //    super(context);
    //}

    public GameView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public GameView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public GameView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public GameView(Context context){
        super(context);

        JOYSTICK_BASE_PAINT = new Paint();
        JOYSTICK_BASE_PAINT.setColor(JOYSTICK_BASE_COLOR);
        JOYSTICK_HANDLE_PAINT = new Paint();
        JOYSTICK_HANDLE_PAINT.setColor(JOYSTICK_HANDLE_COLOR);
        invalidate();
        Thread t = new Thread(this);
        t.start();
    }

    @Override
    public void run() {
        while(true){
            Thread.sleep(10);
        }
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        setBackgroundColor(0xFF006600);
        /*if(isJoyStickOn){
            canvas.drawCircle(joystickBaseCenter.x, joystickBaseCenter.y,
                    JOYSTICK_BASE_RADIUS, JOYSTICK_BASE_PAINT);
            canvas.drawCircle(joystickHandleCenter.x, joystickHandleCenter.y,
                    JOYSTICK_HANDLE_RADIUS, JOYSTICK_HANDLE_PAINT);
        }*/
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int x = (int)event.getX(), y = (int)event.getY();
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                isJoyStickOn = true;
                joystickBaseCenter = new Point(x,y);
                joystickHandleCenter = new Point(x,y);
                break;
            case MotionEvent.ACTION_UP:
                joystickHandleCenter = new Point(joystickBaseCenter);
                isJoyStickOn = false;
            case MotionEvent.ACTION_MOVE:
                joystickHandleCenter = new Point(x,y);
        }
        return super.onTouchEvent(event);
    }
}
