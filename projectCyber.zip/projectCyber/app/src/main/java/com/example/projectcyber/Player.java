package com.example.projectcyber;

public class Player extends Entity{

}
